CREATE PROCEDURE dbo.JoinClan
(
	@clanId INT,
	@userId INT
)
AS
	UPDATE Player SET clan = @clanId WHERE id = @userId;
go

